<!DOCTYPE html>
<html>
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="author" content="Just Digital Tech">
    <link rel="shortcut icon" type="image/x-icon" href="faviconf27d.ico?v=2.0.4">
	  <link rel="icon" type="image/x-icon" href="faviconf27d.ico?v=2.0.4">
    <title>Contact Us - Limpid Wallet</title>
		<meta name="keywords" content="Money, pay, send, receive, sending, receiving, global, world, worldwide, global pay, Bitcoin, Etherium, Crypto, Crypto currency, transfer">
    <meta name="description" content="Best High volume money transfer platform sending and receiving money globally across all countries.">

    <!-- Bootstrap core CSS -->
    <link href="assets/themes/escrow/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/themes/escrow/css/escrow.css" rel="stylesheet">
		<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
		<script src='../www.google.com/recaptcha/api.js'></script>
</head>

<body>
	
	<nav class="navbar navbar-expand-md navbar-dark">
		<div class="container">
      <a class="navbar-brand" href="#">
				<img src="assets/themes/account/img/main-logo.png" height="30" alt="">
			</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item ">
            <a class="nav-link" href="index.html">Home</a>
          </li>
					<li class="nav-item ">
            <a class="nav-link" href="how-it-works.html">Purchase protect</a>
          </li>
					<li class="nav-item ">
            <a class="nav-link" href="developers.html">For developers</a>
          </li>
					<!--<li class="nav-item ">-->
     <!--       <a class="nav-link" href=""></a>-->
     <!--     </li>-->
          <li class="nav-item active">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
         
        </ul>
        <div class="form-inline my-2 my-lg-0">
					          <a href="login.php" class="btn btn-outline-light my-2 my-sm-0 mr-3">Sign in</a>
          <a href="user/register.php" class="btn btn-success my-2 my-sm-0">Create account</a>
					        </div>
				
      </div>
		</div>
    </nav>

    	<main>
            
<div class="header-st2 mb-head">
			<div class="container">
				<div class="row">
          <div class="col-md-2">
            
          </div>
          <div class="col-md-8">
            <div class="card mb-5">
              <form action="https://Limpidwallet.com/contact" role="form" method="post" accept-charset="utf-8">
                                                        <input type="hidden" name="csrf_token" value="4e8faf031531b439abe20fe118913744" />
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <h5 class="text-center">
                      Contact Us                    </h5>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="name" class="control-label">Name</label>                      <span class="required">*</span>
                      <input type="text" name="name" value="" class="form-control"  />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="email" class="control-label">Email</label>                      <span class="required">*</span>
                      <input type="text" name="email" value="" class="form-control"  />
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="title" class="control-label">Title</label>                      <span class="required">*</span>
                      <input type="text" name="title" value="" class="form-control"  />
                    </div>
                  </div>
                   <div class="col-md-12">
                    <div class="form-group">
                      <label for="message" class="control-label">Message</label>                      <span class="required">*</span>
                      <textarea name="message" cols="40" rows="5" class="form-control" ></textarea>
                    </div>
                  </div>
                  <div class="col-md-12 mb-3">
                    <div class="g-recaptcha text-center" data-sitekey="6LegMLMZAAAAAP1b4eRydYSL8TYH5eQ0HECIu2yW"></div>
                  </div>
                  <div class="col-md-12 text-right">
                      <button type="submit" name="submit" class="btn btn-success"> Send</button>
                  </div>
                </div>
              </div>
              </form>            </div>
          </div>
          <div class="col-md-2">
            
          </div>
        </div>
  </div>
</div>

<div class="container">
			<div class="row mt-10">
				<div class="col-md-12 mt-5">
					<h2 class="text-center">
						Connect with us					</h2>
				</div>
        <div class="col-md-4 mt-5">
					<div class="text-center">
						<h1>
              <i class="icon-envelope icons text-primary"></i>
            </h1>
						<h5 class="mt-3">info@limpidwallet.com</h5>
						<p class="mt-3">We will need up to 2 business days</p>
					</div>
				</div>
        
				<div class="col-md-4 mt-5">
					<div class="text-center">
						<h1>
              <i class="icon-phone icons text-primary"></i>
            </h1>
						<h5 class="mt-3">EMAIL & MESSAGES</h5>
						<p class="mt-3">We will respond on any day and time</p>
					</div>
				</div>
        
        <div class="col-md-4 mt-5">
					<div class="text-center">
						<h1>
              <i class="icon-social-skype icons text-primary"></i>
            </h1>
						<h5 class="mt-3">Limpidwallet</h5>
						<p class="mt-3">Support only in chat</p>
					</div>
				</div>
        
			</div>
		</div>

<div class="top-merchant mt-5">
			<div class="container">
				<div class="row">
					<div class="col-md-12 mt-4">
						<h4 class="text-center">
							Create account and get started						</h4>
					</div>
					<div class="col-md-12 mt-4 mb-4">
						<h4 class="text-center">
							<a href="register.php" class="btn btn-success btn-lg">Sign up</a>
						</h4>
					</div>
				</div>
			</div>
		</div>	</main>
	
	        
        <footer>
			
			<div class="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-10">
							<ul class="list-inline">
								<li class="list-inline-item mr-4">All Rights reserved</li>
								<li class="list-inline-item mr-4">Copyright &copy 2021</li>
								<!--<li class="list-inline-item mr-4"><a href=""></a></li>-->
							</ul>
						</div>
						<div class="col-md-2">
							<div class="dropdown dropup text-right">
								<button id="session-language" class="btn btn-light dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									Language								</button>
								<div id="session-language-dropdown" class="dropdown-menu" aria-labelledby="session-language">
																		<a class="dropdown-item" href="#" rel="english">
																								<i class="icon-arrow-right icons"></i>
																						English									</a>
																	</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
        
    </footer>
	
	 <!-- Placed at the end of the document so the pages load faster -->
	
    <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="../code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="../cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="../maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
	
	                                                        
<script type="text/javascript" src="../ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.minf27d.js?v=2.0.4"></script>
                                                                
<script type="text/javascript" src="../maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.minf27d.js?v=2.0.4"></script>
                                                                
<script type="text/javascript">
/**
 * Configurations
 */
var config = {
    logging : true,
    baseURL : "https://Limpidwallet.com/"
};


/**
 * Bootstrap IE10 viewport bug workaround
 */
if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
    var msViewportStyle = document.createElement('style')
    msViewportStyle.appendChild(
        document.createTextNode(
            '@-ms-viewport{width:auto!important}'
        )
    )
    document.querySelector('head').appendChild(msViewportStyle)
}


/**
 * Execute an AJAX call
 */
function executeAjax(url, data, callback) {
    $.ajax({
        type     : 'POST',
        url      : url,
        data     : data,
        dataType : 'json',
        async    : true,
        success  : function(results) {
            callback(results);
        },
        error    : function(error) {
            alert("Error " + error.status + ": " + error.statusText);
        }
    });
    // prevent default action
    return false;
}


/**
 * Global core functions
 */
$(document).ready(function() {

    /**
     * Session language selected
     */
    $('#session-language-dropdown a').click(function(e) {
        // prevent default behavior
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }

        // set up post data
        var postData = {
            language : $(this).attr('rel')
        };

        // define callback function to handle AJAX call result
        var ajaxResults = function(results) {
            if (results.success) {
                location.reload();
            } else {
                alert("There was a problem setting the language!");
            }
        };

        // perform AJAX call
        executeAjax(config.baseURL + 'ajax/set_session_language', postData, ajaxResults);
    });

});

</script>
                  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js?v=2.0.4"></script>
                                                                
<script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js?v=2.0.4"></script>       

   <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/605e997cf7ce182709346d00/1f1oof3ru';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> 

</body>
</html>

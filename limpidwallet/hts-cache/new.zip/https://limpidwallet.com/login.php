<!DOCTYPE html>
<html>
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="author" content="Just Digital Tech">
    <link rel="shortcut icon" type="image/x-icon" href="faviconf27d.ico?v=2.0.4">
	  <link rel="icon" type="image/x-icon" href="faviconf27d.ico?v=2.0.4">
    <title>Sign in - Limpid Wallet</title>
		<meta name="keywords" content="Money, pay, send, receive, sending, receiving, global, world, worldwide, global pay, Bitcoin, Etherium, Crypto, Crypto currency, transfer">
    <meta name="description" content="Best High volume money transfer platform sending and receiving money globally across all countries.">

    <!-- Bootstrap core CSS -->
    <link href="assets/themes/escrow/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/themes/escrow/css/escrow.css" rel="stylesheet">
		<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
		<script src='../www.google.com/recaptcha/api.js'></script>
</head>

<body>
	
	<nav class="navbar navbar-expand-md navbar-dark">
		<div class="container">
      <a class="navbar-brand" href="#">
				<img src="assets/themes/account/img/main-logo.png" height="30" alt="">
			</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item ">
            <a class="nav-link" href="index.html">Home</a>
          </li>
					<li class="nav-item ">
            <a class="nav-link" href="how-it-works.html">Purchase protect</a>
          </li>
					<li class="nav-item ">
            <a class="nav-link" href="developers.html">For developers</a>
          </li>
					<!--<li class="nav-item ">-->
     <!--       <a class="nav-link" href=""></a>-->
     <!--     </li>-->
          <li class="nav-item ">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
         
        </ul>
        <div class="form-inline my-2 my-lg-0">
					          <a href="login.php" class="btn btn-outline-light my-2 my-sm-0 mr-3">Sign in</a>
          <a href="user/register.php" class="btn btn-success my-2 my-sm-0">Create account</a>
					        </div>
				
      </div>
		</div>
    </nav>

    	<main>
            
<div class="header-st mb-4">
			<div class="container">
				<div class="row">
          <div class="col-md-12">
            <h3>
              Sign in            </h3>
          </div>
        </div>
  </div>
</div>

<div class="container">
  <div class="row mt-5">
  <div class="col-md-6 offset-md-3">
    <div class="card">
      <div class="card-body">
        <form ACTION="/login.php" METHOD="POST" name="loginform" accept-charset="utf-8">
                              
          <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <input type="text" name="username" value="" id="username" class="form-control" placeholder="Enter username" maxlength="256" required />
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" name="password" value="" id="password" class="form-control" placeholder="Enter password" maxlength="72" autocomplete="off" required />
          </div>
          <div class="row">
            <div class="col-md-12">
            
            </div>
            <div class="col-md-6">
              <a href="user/forgot.php">Forgot your password?</a></br>
              <a href="user/register.php">Create account</a>
            </div>

            <div class="col-md-6 text-right">
              <button type="submit" class="btn btn-success">Login</button>
            </div>
          </div>
        </form>      </div>
    </div>
  </div>
</div>
</div>
	</main>
	
	
	
	
	        
        <footer>
			
			<div class="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-10">
							<ul class="list-inline">
								<li class="list-inline-item mr-4">All Rights reserved</li>
								<li class="list-inline-item mr-4">Copyright &copy 2021</li>
								<!--<li class="list-inline-item mr-4"><a href=""></a></li>-->
							</ul>
						</div>
						<div class="col-md-2">
							<div class="dropdown dropup text-right">
								<button id="session-language" class="btn btn-light dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									Language								</button>
								<div id="session-language-dropdown" class="dropdown-menu" aria-labelledby="session-language">
																		<a class="dropdown-item" href="#" rel="english">
																								<i class="icon-arrow-right icons"></i>
																						English									</a>
																	</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
        
    </footer>
	
	 <!-- Placed at the end of the document so the pages load faster -->
	
    <script src="../code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="../cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="../maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
	
	                                                        
<script type="text/javascript" src="../ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.minf27d.js?v=2.0.4"></script>
                                                                
<script type="text/javascript" src="../maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.minf27d.js?v=2.0.4"></script>
                                                                
<script type="text/javascript">
/**
 * Configurations
 */
var config = {
    logging : true,
    baseURL : "https://Limpidwallet.com/"
};


/**
 * Bootstrap IE10 viewport bug workaround
 */
if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
    var msViewportStyle = document.createElement('style')
    msViewportStyle.appendChild(
        document.createTextNode(
            '@-ms-viewport{width:auto!important}'
        )
    )
    document.querySelector('head').appendChild(msViewportStyle)
}


/**
 * Execute an AJAX call
 */
function executeAjax(url, data, callback) {
    $.ajax({
        type     : 'POST',
        url      : url,
        data     : data,
        dataType : 'json',
        async    : true,
        success  : function(results) {
            callback(results);
        },
        error    : function(error) {
            alert("Error " + error.status + ": " + error.statusText);
        }
    });
    // prevent default action
    return false;
}


/**
 * Global core functions
 */
$(document).ready(function() {

    /**
     * Session language selected
     */
    $('#session-language-dropdown a').click(function(e) {
        // prevent default behavior
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }

        // set up post data
        var postData = {
            language : $(this).attr('rel')
        };

        // define callback function to handle AJAX call result
        var ajaxResults = function(results) {
            if (results.success) {
                location.reload();
            } else {
                alert("There was a problem setting the language!");
            }
        };

        // perform AJAX call
        executeAjax(config.baseURL + 'ajax/set_session_language', postData, ajaxResults);
    });

});

</script>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js?v=2.0.4"></script>
                                                                
<script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js?v=2.0.4"></script>                                      
</body>
</html>
  